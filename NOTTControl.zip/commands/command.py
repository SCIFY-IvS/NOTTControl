class Command():
    def __init__(self):
        pass

    def execute(self):
        pass

    def text(self):
        pass

    def is_synchronous(self):
        pass